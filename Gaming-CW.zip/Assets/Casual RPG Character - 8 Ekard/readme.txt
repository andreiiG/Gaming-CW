            ▶ >>JJ Studio <<◀

Character Pack optimized for Mobile RPG implementations!


-----------------------------------------------------------------
Casual RPG Character Series / 08 / Ekard

Polys: 2512
Verts: 2237
Texture: 1024x1024-1, 256x256-1  

Character Icon: 256x320-1

Animations(x7) :
(Animation Type_Generic)
Sword_M_BattleIdle_01
Sword_M_Run_01
Sword_M_Attack_01
Sword_M_Attack_02
Ekard_Skill_01
Sword_M_Debuff_01
Sword_M_Stun_01
-----------------------------------------------------------------


Thank you for your purchase!
If you have any questions mail me at 2018studiojj@gmail.com


▼Check out our other Assets▼
https://assetstore.unity.com/publishers/38479